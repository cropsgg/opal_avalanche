import { LandingHero } from '@/components/landing/LandingHero';
import { FeaturesSection } from '@/components/landing/FeaturesSection';
import { Header } from '@/components/layout/Header';

export default function Home() {
  return (
    <div className="min-h-screen bg-cream-50">
      <Header />
      <LandingHero />
      <FeaturesSection />
    </div>
  );
}